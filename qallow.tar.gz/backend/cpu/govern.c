#include "govern.h"
#include <stdio.h>
#include <time.h>
#include <string.h>
#include <stdlib.h>

// Initialize governance state
void govern_init(govern_state_t* gov) {
    if (!gov) return;
    
    gov->current_ethics_score = 0.0f;
    gov->previous_ethics_score = 0.0f;
    gov->audit_count = 0;
    gov->violations_detected = 0;
    gov->system_stable = true;
    gov->adaptation_active = false;
    gov->last_audit_time = (double)time(NULL);
    gov->total_govern_time = 0.0;
}

// Evaluate current ethics score
float govern_evaluate_ethics(qallow_state_t* state, ethics_monitor_t* ethics) {
    if (!state || !ethics) return 0.0f;
    
    float safety = ethics_calculate_safety_score(state, ethics);
    float clarity = ethics_calculate_clarity_score(state, ethics);
    float human_benefit = ethics_calculate_human_benefit_score(state, ethics);
    
    float total = safety + clarity + human_benefit;
    return total;
}

// Check if ethics score meets safety threshold
bool govern_check_safety_threshold(float ethics_score) {
    return ethics_score >= GOVERN_ETHICS_THRESHOLD;
}

// Log audit result
void govern_log_audit_result(const govern_state_t* gov, float ethics_score) {
    printf("[GOVERN] Audit #%d: Ethics Score = %.4f\n", gov->audit_count, ethics_score);
    
    if (ethics_score < GOVERN_ETHICS_THRESHOLD) {
        printf("[GOVERN] ⚠️  WARNING: Ethics score below threshold (%.4f < %.4f)\n", 
               ethics_score, GOVERN_ETHICS_THRESHOLD);
    } else {
        printf("[GOVERN] ✓ Ethics score acceptable\n");
    }
}

// Adapt parameters based on governance state
void govern_adapt_parameters(adaptive_state_t* adaptive, const govern_state_t* gov) {
    if (!adaptive || !gov) return;
    
    // Adjust learning rate based on stability
    if (gov->system_stable) {
        adaptive->learning_rate *= 1.05;  // Increase learning when stable
        if (adaptive->learning_rate > 0.1) {
            adaptive->learning_rate = 0.1;  // Cap at 0.1
        }
    } else {
        adaptive->learning_rate *= 0.95;  // Decrease learning when unstable
        if (adaptive->learning_rate < 0.001) {
            adaptive->learning_rate = 0.001;  // Floor at 0.001
        }
    }
    
    // Adjust thread count based on ethics score
    if (gov->current_ethics_score > 3.0f) {
        adaptive->threads = (adaptive->threads < 16) ? adaptive->threads + 1 : 16;
    } else if (gov->current_ethics_score < 2.5f) {
        adaptive->threads = (adaptive->threads > 1) ? adaptive->threads - 1 : 1;
    }
}

// Reinforce learning based on performance
void govern_reinforce_learning(adaptive_state_t* adaptive, float performance_delta) {
    if (!adaptive) return;
    
    // Positive delta: increase human score
    if (performance_delta > 0.0f) {
        adaptive->human_score += performance_delta * 0.1;
        if (adaptive->human_score > 1.0) {
            adaptive->human_score = 1.0;
        }
    } else {
        adaptive->human_score += performance_delta * 0.05;
        if (adaptive->human_score < 0.0) {
            adaptive->human_score = 0.0;
        }
    }
}

// Verify sandbox integrity
bool govern_verify_sandbox_integrity(sandbox_manager_t* sandbox, qallow_state_t* state) {
    if (!sandbox || !state) return false;
    
    // Check if we can create a snapshot (basic integrity test)
    return sandbox_is_state_safe(state);
}

// Create safety checkpoint
void govern_create_safety_checkpoint(sandbox_manager_t* sandbox, qallow_state_t* state) {
    if (!sandbox || !state) return;
    
    char checkpoint_name[64];
    snprintf(checkpoint_name, sizeof(checkpoint_name), "govern_checkpoint_%lu", state->tick_count);
    
    if (sandbox_create_snapshot(sandbox, state, checkpoint_name)) {
        printf("[GOVERN] Safety checkpoint created: %s\n", checkpoint_name);
    } else {
        printf("[GOVERN] ⚠️  Failed to create safety checkpoint\n");
    }
}

// Halt on violation
void govern_halt_on_violation(qallow_state_t* state, const char* reason) {
    if (!state || !reason) return;
    
    printf("\n╔════════════════════════════════════════╗\n");
    printf("║  GOVERNANCE HALT - VIOLATION DETECTED  ║\n");
    printf("╚════════════════════════════════════════╝\n");
    printf("[GOVERN] Reason: %s\n", reason);
    printf("[GOVERN] System halted at tick %lu\n", state->tick_count);
}

// Emergency rollback
void govern_emergency_rollback(sandbox_manager_t* sandbox, qallow_state_t* state) {
    if (!sandbox || !state) return;
    
    printf("[GOVERN] Initiating emergency rollback...\n");
    sandbox_force_rollback(sandbox, state);
    printf("[GOVERN] Emergency rollback completed\n");
}

// Persist governance state
void govern_persist_state(const govern_state_t* gov, const adaptive_state_t* adaptive) {
    if (!gov || !adaptive) return;
    
    // Save adaptive state (which includes learning parameters)
    adaptive_save(adaptive);
    
    printf("[GOVERN] Governance state persisted\n");
}

// Load governance state
void govern_load_state(govern_state_t* gov, adaptive_state_t* adaptive) {
    if (!gov || !adaptive) return;
    
    // Load adaptive state
    adaptive_load(adaptive);
    
    printf("[GOVERN] Governance state loaded\n");
}

// Print audit report
void govern_print_audit_report(const govern_state_t* gov) {
    if (!gov) return;
    
    printf("\n═══ GOVERNANCE AUDIT REPORT ═══\n");
    printf("[GOVERN] Total audits: %d\n", gov->audit_count);
    printf("[GOVERN] Violations detected: %d\n", gov->violations_detected);
    printf("[GOVERN] Current ethics score: %.4f\n", gov->current_ethics_score);
    printf("[GOVERN] System stable: %s\n", gov->system_stable ? "YES" : "NO");
    printf("[GOVERN] Adaptation active: %s\n", gov->adaptation_active ? "YES" : "NO");
    printf("[GOVERN] Total governance time: %.2f seconds\n", gov->total_govern_time);
}

// Print governance summary
void govern_print_governance_summary(const govern_state_t* gov, float final_ethics_score) {
    if (!gov) return;
    
    printf("\n╔════════════════════════════════════════╗\n");
    printf("║   AUTONOMOUS GOVERNANCE SUMMARY        ║\n");
    printf("╚════════════════════════════════════════╝\n");
    printf("[GOVERN] Final Ethics Score: %.4f\n", final_ethics_score);
    printf("[GOVERN] Threshold: %.4f\n", GOVERN_ETHICS_THRESHOLD);
    printf("[GOVERN] Status: %s\n", final_ethics_score >= GOVERN_ETHICS_THRESHOLD ? "✓ PASS" : "✗ FAIL");
    printf("[GOVERN] Audits performed: %d\n", gov->audit_count);
    printf("[GOVERN] Violations: %d\n", gov->violations_detected);
}

// Main autonomous governance loop
void govern_run_audit_loop(govern_state_t* gov, qallow_state_t* state,
                           ethics_monitor_t* ethics, sandbox_manager_t* sandbox,
                           adaptive_state_t* adaptive) {
    if (!gov || !state || !ethics || !sandbox || !adaptive) return;
    
    printf("\n╔════════════════════════════════════════╗\n");
    printf("║  AUTONOMOUS GOVERNANCE LOOP STARTING   ║\n");
    printf("╚════════════════════════════════════════╝\n\n");
    
    double start_time = (double)time(NULL);
    
    // Perform initial audit
    gov->current_ethics_score = govern_evaluate_ethics(state, ethics);
    gov->audit_count++;
    govern_log_audit_result(gov, gov->current_ethics_score);
    
    // Check safety threshold
    if (!govern_check_safety_threshold(gov->current_ethics_score)) {
        gov->violations_detected++;
        govern_halt_on_violation(state, "Initial ethics score below threshold");
        govern_emergency_rollback(sandbox, state);
        govern_print_governance_summary(gov, gov->current_ethics_score);
        return;
    }
    
    // Create initial safety checkpoint
    govern_create_safety_checkpoint(sandbox, state);
    
    // Verify sandbox integrity
    if (!govern_verify_sandbox_integrity(sandbox, state)) {
        printf("[GOVERN] ⚠️  Sandbox integrity check failed\n");
        gov->violations_detected++;
    }
    
    // Adapt system parameters
    gov->adaptation_active = true;
    govern_adapt_parameters(adaptive, gov);
    
    // Reinforce learning
    float performance_delta = gov->current_ethics_score - GOVERN_ETHICS_THRESHOLD;
    govern_reinforce_learning(adaptive, performance_delta);
    
    // Persist state
    govern_persist_state(gov, adaptive);
    
    // Calculate total governance time
    double end_time = (double)time(NULL);
    gov->total_govern_time = end_time - start_time;
    
    // Print final report
    govern_print_audit_report(gov);
    govern_print_governance_summary(gov, gov->current_ethics_score);
    
    printf("\n[GOVERN] Autonomous governance loop completed successfully\n");
}

